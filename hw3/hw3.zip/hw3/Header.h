//
//  Header.h
//  hw3
//
//  Created by Kyleen Gonzalez on 4/21/17.
//  Copyright © 2017 Kyleen Gonzalez. All rights reserved.
//

#ifndef Header_h
#define Header_h
const int rows= 3;//declaring information day and high and low
const int columns = 31;//declaring days or columns for array

void averageHighLow(int array[][columns]);

void highestLow(int array[][ columns]);

void lowestHigh(int array[][columns]);

void countHighLow(int array[][columns]);

#endif /* Header_h */
